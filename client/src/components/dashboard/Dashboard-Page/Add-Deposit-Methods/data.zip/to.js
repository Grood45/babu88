const fs = require('fs');

// ফাইল থেকে ডেটা পড়া
let data = fs.readFileSync('data.txt', 'utf8');

// শেষের সেমিকোলন মুছে দাও
data = data.replace(/;$/, '');

// প্রতিটি রেকর্ড আলাদা করা
let rows = data.split(/\),\s*\(/);

// প্রতিটি রেকর্ড প্রসেস
let result = rows.map(row => {
    row = row.replace(/^\(/, '').replace(/\)$/, '');
    let cols = row.split(/,(?=(?:[^']*'[^']*')*[^']*$)/);
    cols = cols.map(col => col.trim().replace(/^'(.*)'$/, '$1'));

    return {
        id: parseInt(cols[0]),
        provider_id: parseInt(cols[1]),
        category_id: parseInt(cols[2]),
        name: cols[3],
        game_uuid: cols[4],
        image: cols[5],
        status: parseInt(cols[6]),
        created_at: cols[7],
        updated_at: cols[8]
    };
});

// JSON ফাইলে লিখে দাও
fs.writeFileSync('data.json', JSON.stringify(result, null, 2));

console.log('Conversion done! Check data.json file.');
